from django.shortcuts import render_to_response
from blog.models import Post
from django.http import HttpResponse
from forms import CreateBlog
from django.http import HttpResponseRedirect
from django.core.context_processors import csrf

# Create your views here.



